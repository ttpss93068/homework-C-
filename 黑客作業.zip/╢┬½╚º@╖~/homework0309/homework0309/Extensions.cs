﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace homework0309
{
    public static class Extensions
    {
        public static IEnumerable<T> R<T>(this IEnumerable<T> source) 
        {
            return new Stack<T>(source);
        }
    }
}
