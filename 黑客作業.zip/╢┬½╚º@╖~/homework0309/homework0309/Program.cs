﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace homework0309
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] s = { "1", "2", "3", "4", "5" };
            var result = s.R();
            foreach (var item in result) 
            {
                Console.WriteLine(item);
            }           
            Console.ReadLine();
        }
    }
}
