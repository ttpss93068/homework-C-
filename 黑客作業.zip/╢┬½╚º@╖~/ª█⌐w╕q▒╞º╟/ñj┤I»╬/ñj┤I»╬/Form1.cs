﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using 大富翁.Blocks;

namespace 大富翁
{
    public partial class Form1 : Form
    {
        private List<Block> Blocks = new List<Block>();
        private Random random = new Random();
        public Form1()
        {
            InitializeComponent();
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Map_pictureBox.Load($"{System.AppDomain.CurrentDomain.BaseDirectory}/PictureSource/map.png");
            player_pictureBox.Load($"{System.AppDomain.CurrentDomain.BaseDirectory}/PictureSource/player.bmp");

            player_pictureBox.Location = new Point(Map_pictureBox.Location.X + 25, Map_pictureBox.Location.Y + 25);


            Blocks = new List<Block>()
            {
                new GrayBlock(new Point(0,0)),
                new BlueBlock(new Point(100,0)),
                new RedBlock(new Point(200,0)),
                new BrownBlock(new Point(300,0)),
                new BlueBlock(new Point(300,100)),
                new RedBlock(new Point(300,200)),
                new BrownBlock(new Point(300,300)),
                new BlueBlock(new Point(200,300)),
                new RedBlock(new Point(100,300)),
                new BrownBlock(new Point(0,300)),
                new BlueBlock(new Point(0,200)),
                new RedBlock(new Point(0,100))
            };
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int rNum = random.Next(3) + 1;
            label1.Text = rNum.ToString();
        }
    }
}
