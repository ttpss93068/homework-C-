﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 大富翁.Blocks
{
    interface IBlock
    {
        int StopAction (int source );
    }
}
