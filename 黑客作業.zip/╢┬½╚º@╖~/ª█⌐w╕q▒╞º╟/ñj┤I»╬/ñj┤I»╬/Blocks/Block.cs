﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 大富翁.Blocks
{
    class Block : IBlock 
    {
        public Block(Point p) 
        {
            Location = p;
        }
        public Point Location { get; set; }

        public virtual int StopAction(int source)
        {
            return source + 10;
        }
    }
}
