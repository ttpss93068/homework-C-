﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 大富翁.Blocks
{
    class BlueBlock : Block
    {
        public BlueBlock(Point p) : base(p) { }
        public override int StopAction(int source)
        {
            return source - 20;
        }
    }
}
