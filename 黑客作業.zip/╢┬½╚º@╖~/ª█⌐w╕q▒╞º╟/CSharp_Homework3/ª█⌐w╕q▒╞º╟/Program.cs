﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 自定義排序
{
    class Program
    {
        static void Main(string[] args)
        {
            var _list = new List<string>() { "牛", "豬", "鼠", "羊", "狗" };
            var test = _list.OrderBy((x) => x, new MyCompare());
            foreach (var item in test) 
            {
                Console.WriteLine(item);
            }
            Console.ReadLine();
        }
        public class MyCompare : IComparer<string>
        {
            private List<string> zod = new List<string>() { "鼠", "牛", "虎", "兔", "龍", "蛇", "馬", "羊", "猴", "雞", "狗", "豬" };
            public int Compare(string x, string y)
            {
                return zod.IndexOf(x) - zod.IndexOf(y);
            }
        }

        //public class MyCompare : IComparer<string>
        //{
        //    private List<string> zod = new List<string>() { "鼠", "牛", "虎", "兔", "龍", "蛇", "馬", "羊", "猴", "雞", "狗", "豬" };

        //    public int Compare(string x, string y)
        //    {
        //        int result = 0;
        //        int index_x = zod.IndexOf(x);
        //        int index_y = zod.IndexOf(y);
        //        if (index_x - index_y < 0) 
        //        {
        //            result = -1;
        //        }
        //        else if (index_x - index_y > 0)
        //        {
        //            result = 1;
        //        }
        //        else if (index_x - index_y == 0) 
        //        {
        //            result = 0;
        //        }
        //        return result;
        //    }
        //}
    }
}
