﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _004.Models
{
    class Seller
    {
        /// <summary>
        /// 姓名
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 銷售清單
        /// </summary>
        public Dictionary<string, int> SellList { get; set; }
        //public double PenVolume { get; set; }
        //public double PencilVolume { get; set; }
        //public double EraserVolume { get; set; }
        //public double RulerVolume { get; set; }
        //public double LicoWhiteVolume { get; set; }
    }
}
