﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using _004.Models;

namespace _004
{
    public partial class Form1 : Form
    {
        List<Product> ProductList;
        List<Seller> SellerList;

        public Form1()
        {
            InitializeComponent();
            CreateSourceList();
        }

        private void CreateSourceList()
        {
            ProductList = new List<Product>();
            ProductList.Add(new Product() { ItemName = "原子筆", Price = 12 });
            ProductList.Add(new Product() { ItemName = "鉛筆", Price = 16 });
            ProductList.Add(new Product() { ItemName = "橡皮擦", Price = 10 });
            ProductList.Add(new Product() { ItemName = "直尺", Price = 14 });
            ProductList.Add(new Product() { ItemName = "立可白", Price = 15 });

            SellerList = new List<Seller>();
            SellerList.Add(new Seller() { Name = "Bill", SellList = new Dictionary<string, int>() { { "原子筆", 33 }, { "鉛筆", 32 }, { "橡皮擦", 56 }, { "直尺", 45 }, { "立可白", 33 } } });
            SellerList.Add(new Seller() { Name = "John", SellList = new Dictionary<string, int>() { { "原子筆", 77 }, { "鉛筆", 33 }, { "橡皮擦", 68 }, { "直尺", 45 }, { "立可白", 23 } } });
            SellerList.Add(new Seller() { Name = "David", SellList = new Dictionary<string, int>() { { "原子筆", 43 }, { "鉛筆", 55 }, { "橡皮擦", 43 }, { "直尺", 67 }, { "立可白", 65 } } });
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            var ItemAnsList = (from item in ProductList
                              select new
                              {
                                  ItemName = item.ItemName,
                                  Price = item.Price,
                                  ItemTotalSum = SellerList.Sum(x => x.SellList.Where(y => y.Key == item.ItemName).FirstOrDefault().Value) * item.Price
                              }).ToList();

            var SellerAnsList = (from item in SellerList
                                select new
                                {
                                    SellerName = item.Name,
                                    PenTotal = item.SellList.Where(x => x.Key == "原子筆").FirstOrDefault().Value * ProductList.Find(x => x.ItemName == "原子筆").Price,
                                    PencilTotal = item.SellList.Where(x => x.Key == "鉛筆").FirstOrDefault().Value * ProductList.Find(x => x.ItemName == "鉛筆").Price,
                                    EraserTotal = item.SellList.Where(x => x.Key == "橡皮擦").FirstOrDefault().Value * ProductList.Find(x => x.ItemName == "橡皮擦").Price,
                                    RulerTotal = item.SellList.Where(x => x.Key == "直尺").FirstOrDefault().Value * ProductList.Find(x => x.ItemName == "直尺").Price,
                                    LicoTotal = item.SellList.Where(x => x.Key == "立可白").FirstOrDefault().Value * ProductList.Find(x => x.ItemName == "立可白").Price,
                                    Total = ProductList.Sum(x => x.Price * item.SellList.Where(y => y.Key == x.ItemName).FirstOrDefault().Value)
                                }).ToList();

            //畫面顯示
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            dataGridView1.DataSource = SellerAnsList;
            dataGridView2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            dataGridView2.DataSource = ItemAnsList;

            label1.Text = SellerAnsList.Find(x => x.Total == SellerAnsList.Max(y => y.Total)).SellerName;

            label2.Text = ItemAnsList.Find(x => x.ItemTotalSum == ItemAnsList.Max(y => y.ItemTotalSum)).ItemName;
        }
    }
}
