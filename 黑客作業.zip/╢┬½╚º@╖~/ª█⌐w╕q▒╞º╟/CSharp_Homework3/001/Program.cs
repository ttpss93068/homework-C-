﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _001
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Input Max number : ");
            int input = int.Parse(Console.ReadLine());
            List<int> numberList = new List<int>();

            numberList = Count(input);

            int Ans = numberList.Sum();

            #region Show算式
            Console.Write($"{Environment.NewLine}{numberList.First()}");
            for (int i = 1; i < numberList.Count; i++)
            {
                Console.Write(numberList[i].ToString(" + #; - #;0"));
            }
            #endregion

            Console.Write($" = {Ans}");
            Console.ReadLine();
        }

        private static List<int> Count(int input)
        {
            List<int> result = new List<int>();

            for(int i=1; i<=input; i++)
            {
                if (i % 2 == 0)
                {
                    result.Add(i * -1);
                    continue;
                }
                result.Add(i);
            }

            return result;
        }
    }
}
