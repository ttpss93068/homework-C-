﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 每一年有幾個周日和周六01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text == "民國")
            {
                
                int v1 = int.Parse(domainUpDown1.Text);
                int y1 = v1 + 1911;
                int sun_s = 0, sat_s = 0;
                
                DateTime n1 = new DateTime(y1, 1, 1);
                
                if (DateTime.IsLeapYear(y1) == true)
                    for (int i = 1; i <= 366; i++)
                    {

                        if ((int)n1.DayOfWeek == 0)
                        {
                            sun_s++;
                        }
                        else if ((int)n1.DayOfWeek == 6)
                        {
                            sat_s++;
                        }
                        n1 = n1.AddDays(1);

                    }
                
                else if (DateTime.IsLeapYear(y1) == false)
                    for (int i = 1; i <= 365; i++)
                    {

                        if ((int)n1.DayOfWeek == 0)
                        {
                            sun_s++;
                        }
                        else if ((int)n1.DayOfWeek == 6)
                        {
                            sat_s++;
                        }
                        n1 = n1.AddDays(1);
                    }
                label4.Text = (sun_s) + "天";
                label5.Text = (sat_s) + "天";
            }
            if (comboBox1.Text == "西元")
            {  
                int v1 = int.Parse(domainUpDown1.Text);               
                DateTime n1 = new DateTime(v1, 1, 1);
                int sun_s = 0, sat_s = 0;

                if (DateTime.IsLeapYear(v1) == true)
                    for (int i = 1; i <= 366; i++)
                    {

                        if ((int)n1.DayOfWeek == 0)
                        {
                            sun_s++;
                        }
                        else if ((int)n1.DayOfWeek == 6)
                        {
                            sat_s++;
                        }
                        n1 = n1.AddDays(1);

                    }

                else if (DateTime.IsLeapYear(v1) == false)
                    for (int i = 1; i <= 365; i++)
                    {

                        if ((int)n1.DayOfWeek == 0)
                        {
                            sun_s++;
                        }
                        else if ((int)n1.DayOfWeek == 6)
                        {
                            sat_s++;
                        }
                        n1 = n1.AddDays(1);
                    }
                label4.Text = (sun_s) + "天";
                label5.Text = (sat_s) + "天";
            }
          
        }
    }
}
