﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 迴圈倒置
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("請輸入一組數字(請以逗號隔開): ");
            string[] s1;
            s1 = Console.ReadLine().Split(',');
            Console.Write("倒置後: ");
            for (int i = (s1.Length-1); i >= 0; i--) {
                if (i == 0) { Console.Write(s1[i]); }
                else { Console.Write(s1[i] + ","); } 
            }
            Console.ReadLine();
        }
    }
}
