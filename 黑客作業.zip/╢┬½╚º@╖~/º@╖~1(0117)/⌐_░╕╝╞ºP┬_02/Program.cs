﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 奇偶數判斷02
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("請輸入一組整數: ");
            string[] input;
            List<string> s1 = new List<string>();
            List<string> s2 = new List<string>();
            input = Console.ReadLine().Split(',');
            for (int i = 0; i < input.Length; i++) {
                if (int.Parse(input[i]) % 2 == 0)
                {
                    s1.Add(input[i]);
                }
                else 
                {
                    s2.Add(input[i]);
                }
             }
            Console.Write("偶數: ");
            for (int i = 0; i < s1.Count; i++)
            {
                if (i == (s1.Count-1)) { Console.Write(s1[i]); }
                else { Console.Write(s1[i] + ","); }
            }
            Console.WriteLine();
            Console.Write("奇數: ");
            for (int i=0;i< s2.Count;i++)
            {
                if (i == (s2.Count-1)) { Console.Write(s2[i]); }
                else { Console.Write(s2[i] + ","); }
            }
            Console.ReadLine();
        }
    }
}
