﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 迴圈倒置02
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("請輸入一個整數: ");
            string x;
            x = Console.ReadLine();
            int value = int.Parse(x);
            for (int i = 0; i < value; i++) {
                for (int j = 0; j < (i+1); j++) {
                    Console.Write((value - i));
                }
                Console.WriteLine("");
            }
            Console.ReadLine();
        }
    }
}
