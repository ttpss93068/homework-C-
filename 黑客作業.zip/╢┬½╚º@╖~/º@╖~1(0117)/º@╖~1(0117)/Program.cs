﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 作業1_0117_
{
    class Program
    {
        static void Main(string[] args)
        {
            string input;
            Console.Write("請輸入一個整數: ");
            input = Console.ReadLine();
            int value = int.Parse(input);
            if (value % 2 == 0)
            {
                Console.WriteLine("偶數: " + input);
            }
            else {
                Console.WriteLine("奇數: " + input);
            }
            Console.ReadLine();
        }
    }
}
