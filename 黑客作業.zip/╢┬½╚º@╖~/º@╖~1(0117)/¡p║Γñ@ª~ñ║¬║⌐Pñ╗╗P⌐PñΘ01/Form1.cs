﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 計算一年內的周六與周日01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void Find_ss(int y1,int n1)
        {
            int n2;
            if (0 - n1 < 0) { n2 = 0 - n1 + 7; }
            else { n2 = 0 - n1; }
            long _t1 = new DateTime(y1, 1, n2+1).Ticks;
            long _t2 = new DateTime(y1, 12, 31).Ticks;
            TimeSpan ts = new TimeSpan(_t2 - _t1);
            label4.Text = (ts.Days / 7 + 1) + "天";

            if (6 - n1 < 0) { n2 = 6 - n1 + 7; }
            else { n2 = 6 - n1; }
            long _t3 = new DateTime(y1, 1, n2+1).Ticks;
            long _t4 = new DateTime(y1, 12, 31).Ticks;
            TimeSpan ts2 = new TimeSpan(_t4 - _t3);
            label5.Text = (ts2.Days / 7 + 1) + "天";
        }


        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text == "民國") {
                //星期日
                int v1 = int.Parse(domainUpDown1.Text);
                int y1 = v1 + 1911;
                //List<int> n1 = new List<int>();
                int n1;
                /* string[] wa = { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" };
                 for (int i = 0; i < 7; i++) {
                     if (new DateTime(y1, 1, 1).DayOfWeek.ToString() == wa[i]) {
                         n1.Add(i);
                     }
                 }*/
                //label6.Text=n1[0].ToString();
                //label7.Text = ((int)new DateTime(y1, 1, 1).DayOfWeek).ToString(); 
                n1 = (int)new DateTime(y1, 1, 1).DayOfWeek;

                Find_ss(y1, n1);

                //if (0 - n1 < 0) { n2 = 0 - n1 + 7; }
                //else { n2 = 0 - n1; }
                //long _t1 = new DateTime(y1,1,n2).Ticks;
                //long _t2 = new DateTime(y1,12,31).Ticks;
                //TimeSpan ts= new TimeSpan(_t2 - _t1);
                //label4.Text = (ts.Days / 7 + 1) + "天";

                //星期六
                //if (6 - n1 < 0) { n2 = 6 - n1+ 7; }
                //else { n2 = 6 - n1; }
                //long _t3 = new DateTime(y1, 1, n2).Ticks;
                //long _t4 = new DateTime(y1, 12, 31).Ticks;
                //TimeSpan ts2 = new TimeSpan(_t4 - _t3);
                //label5.Text = (ts2.Days / 7 + 1) + "天";
                
            }
            if (comboBox1.Text == "西元") {
                //星期日
                int v1 = int.Parse(domainUpDown1.Text);
                //List<int> n1 = new List<int>();
                int n1;
                /*string[] wa = { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" };
                for (int i = 0; i < 7; i++)
                {
                    if (new DateTime(v1, 1, 1).DayOfWeek.ToString() == wa[i])
                    {
                        n1.Add(i);
                    }
                }*/
                n1 = (int)new DateTime(v1, 1, 1).DayOfWeek;
                Find_ss(v1, n1);
                //if (0 - n1 < 0) { n2 = 0 - n1 + 7; }
                //else { n2 = 0 - n1; }
                //long _t1 = new DateTime(v1, 1, n2).Ticks;
                //long _t2 = new DateTime(v1, 12, 31).Ticks;
                //TimeSpan ts = new TimeSpan(_t2 - _t1);
                //label4.Text = (ts.Days / 7 + 1) + "天";

                ////星期六
                //if (6 - n1 < 0) { n2 = 6 - n1 + 7; }
                //else { n2 = 6 - n1; }
                //long _t3 = new DateTime(v1, 1, n2).Ticks;
                //long _t4 = new DateTime(v1, 12, 31).Ticks;
                //TimeSpan ts2 = new TimeSpan(_t4 - _t3);
                //label5.Text = (ts2.Days / 7 + 1) + "天";

            }
        }
    }
}
