﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 測試專用
{
    class Program
    {
        static void Main(string[] args)
        {
            string _20190101 = new DateTime(2019, 1, 1).DayOfWeek.ToString();
            for (int i = 0; i < 1; i++)
            {
                Console.WriteLine("DateTime.Now： " + DateTime.Now.ToString());
                Console.WriteLine("DateTime.Today： " + DateTime.Today.ToString());
                Console.WriteLine("DateTime.UtcNow： " + DateTime.UtcNow.ToString());
                Console.WriteLine();
                Console.WriteLine("DateTime.Now.Date： " + DateTime.Now.Date.ToString());
                Console.WriteLine("DateTime.Now.Day： " + DateTime.Now.Day.ToString());
                Console.WriteLine("DateTime.Now.DayOfWeek： " + DateTime.Now.DayOfWeek.ToString());
                Console.WriteLine("DateTime.Now.DayOfYear： " + DateTime.Now.DayOfYear.ToString());
                Console.WriteLine("DateTime.Now.Hour： " + DateTime.Now.Hour.ToString());
                Console.WriteLine("DateTime.Now.Kind： " + DateTime.Now.Kind.ToString());
                Console.WriteLine("DateTime.Now.Millisecond： " + DateTime.Now.Millisecond.ToString());
                Console.WriteLine("DateTime.Now.Minute： " + DateTime.Now.Minute.ToString());
                Console.WriteLine("DateTime.Now.Month： " + DateTime.Now.Month.ToString());
                Console.WriteLine("DateTime.Now.Second： " + DateTime.Now.Second.ToString());
                Console.WriteLine("DateTime.Now.Ticks： " + DateTime.Now.Ticks.ToString());
                Console.WriteLine("DateTime.Now.TimeOfDay： " + DateTime.Now.TimeOfDay.ToString());
                Console.WriteLine("DateTime.Now.Year： " + DateTime.Now.Year.ToString());
                Console.WriteLine("DateTime.Now.DayOfWeek： " + _20190101);

                Console.ReadLine();
            }
            long now = DateTime.Now.Ticks;
            long _20170101 = new DateTime(2017, 1, 1, 5, 9, 6).Ticks;
            TimeSpan TimeSpan = new TimeSpan(now - _20170101);

            Console.WriteLine("DateTime.Now.Ticks：" + now);
            Console.WriteLine("DateTime(2017, 1, 1).Ticks：" + _20170101);
            Console.WriteLine();
            Console.WriteLine("TimeSpan.Days：" + TimeSpan.Days);
            Console.WriteLine("TimeSpan.Hours：" + TimeSpan.Hours);
            Console.WriteLine("TimeSpan.Milliseconds：" + TimeSpan.Milliseconds);
            Console.WriteLine("TimeSpan.Minutes：" + TimeSpan.Minutes);
            Console.WriteLine("TimeSpan.Seconds：" + TimeSpan.Seconds);
            Console.WriteLine("TimeSpan.Ticks：" + TimeSpan.Ticks);
            Console.WriteLine("TimeSpan.TotalDays：" + TimeSpan.TotalDays);
            Console.WriteLine("TimeSpan.TotalHours：" + TimeSpan.TotalHours);
            Console.WriteLine("TimeSpan.TotalMilliseconds：" + TimeSpan.TotalMilliseconds);
            Console.WriteLine("TimeSpan.TotalMinutes：" + (int)TimeSpan.TotalMinutes);
            Console.WriteLine("TimeSpan.TotalSeconds：" + TimeSpan.TotalSeconds);

            Console.ReadLine();
        }
    }
}
