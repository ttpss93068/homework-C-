﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 判斷閏年
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("請輸入一個年份: ");
            string x = Console.ReadLine();
            int year = int.Parse(x);
            if (year % 4 == 0 && year % 100 != 0)
            {
                Console.WriteLine("閏年");
            }
            else if (year % 400 == 0) { Console.WriteLine("閏年"); }
            else { Console.WriteLine("平年"); }
            Console.ReadLine();
        }
    }
}
