﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cross_the_river_0122_
{
    public partial class Form1 : Form
    {
        private List<string> _leftList;
        private List<string> _rightList;


        public Form1()
        {
            InitializeComponent();
            CreateList();
            SetListBoxDataSource();
            ChangeData();
            button2.Enabled = false;
        }

        private void CreateList()
        {
            _leftList = new List<string>
            {
                "農夫","狼","羊","菜"
            };
            _rightList = new List<string>();
        }
        private void SetListBoxDataSource()
        {
            listBox1.SelectionMode = SelectionMode.One;
            listBox2.SelectionMode = SelectionMode.One;

        }

        private void ChangeData()
        {
            listBox1.DataSource = null;
            listBox2.DataSource = null;
            listBox1.DataSource = _leftList;
            listBox2.DataSource = _rightList;
        }


        private void button1_Click(object sender, EventArgs e)
        {
            string _farmer = "農夫";
            bool result_f = _leftList.Any((x) => x == "農夫");

            string item = (string)listBox1.SelectedItem;
            if (result_f)
            {
                if ((string)listBox1.SelectedItem == "農夫")
                {
                    _leftList.Remove(item);
                    _rightList.Add(item);
                }
                else
                {
                    _leftList.Remove(item);
                    _leftList.Remove(_farmer);
                    _rightList.Add(item);
                    _rightList.Add(_farmer);
                }
                ChangeData();
                button1.Enabled = false;
                button2.Enabled = true;
            }
            bool result_w = _leftList.Any((x) => x == "狼");
            bool result_s = _leftList.Any((x) => x == "羊");
            bool result_v = _leftList.Any((x) => x == "菜");
            bool result_ff = _leftList.Any((x) => x == "農夫");
            if (result_w && result_s && result_v) { MessageBox.Show("農夫不在 遊戲失敗"); }
            if (result_w && result_s && (result_v == false)) { MessageBox.Show("羊被吃了 遊戲失敗"); }
            if (result_s && result_v && (result_w == false)) { MessageBox.Show("菜被吃了 遊戲失敗"); }
            if ((result_ff == false) && (result_w == false) && (result_s == false) && (result_v == false)) { MessageBox.Show("遊戲通關"); }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string _farmer = "農夫";
            bool result_f = _rightList.Any((x) => x == "農夫");

            string item = (string)listBox2.SelectedItem;
            if (result_f)
            {
                if ((string)listBox2.SelectedItem == "農夫")
                {
                    _rightList.Remove(item);
                    _leftList.Add(item);
                }
                else
                {
                    _rightList.Remove(item);
                    _rightList.Remove(_farmer);
                    _leftList.Add(item);
                    _leftList.Add(_farmer);
                }
                ChangeData();
                button1.Enabled = true;
                button2.Enabled = false;
            }
            bool result_w = _rightList.Any((x) => x == "狼");
            bool result_s = _rightList.Any((x) => x == "羊");
            bool result_v = _rightList.Any((x) => x == "菜");
            bool result_ff = _leftList.Any((x) => x == "農夫");
            if (result_w && result_s && result_v) { MessageBox.Show("農夫不在 遊戲失敗"); }
            if (result_w && result_s && (result_v == false)) { MessageBox.Show("羊被吃了 遊戲失敗"); }
            if (result_s && result_v && (result_w == false)) { MessageBox.Show("菜被吃了 遊戲失敗"); }
            

        }

        private void button3_Click(object sender, EventArgs e)
        {
            CreateList();
            ChangeData();
            button1.Enabled = true;
            button2.Enabled = false;
        }
    }
}
