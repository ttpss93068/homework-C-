﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 運輸票價
{
    public partial class Form1 : Form
    {
        private Dictionary<string, int> dic_station;
        int[,] pay_array;
        public Form1()
        {
            InitializeComponent();
            Create_ad();
        }
        private void Create_ad() 
        {
            pay_array = new int[6, 6]
            {
                { 0,177,375,598,738,842 },
                { 177,0,197,421,560,755 },
                { 375,197,0,224,363,469 },
                { 598,421,224,0,139,245 },
                { 738,560,363,139,0,106 },
                { 842,755,469,245,106,0 }
            };
            dic_station = new Dictionary<string, int>();
            dic_station.Add("台北", 0);
            dic_station.Add("新竹", 1);
            dic_station.Add("台中", 2);
            dic_station.Add("嘉義", 3);
            dic_station.Add("台南", 4);
            dic_station.Add("高雄", 5);
        }
        private void check_ns(int start,int end) 
        {
            if (radioButton1.Checked == true) 
            {
                if (start >= end) 
                {
                    label3.Text = "錯誤";
                    MessageBox.Show($"請選擇 {comboBox1.Text} 往南的訖站");
                }
            }
            if (radioButton2.Checked == true) 
            {
                if (start <= end) 
                {
                    label3.Text = "錯誤";
                    MessageBox.Show($"請選擇 {comboBox1.Text} 往北的訖站");
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int start = dic_station[comboBox1.Text];
            int end = dic_station[comboBox2.Text];
            int pay = pay_array[start, end];
            if (checkBox1.Checked == true && checkBox2.Checked == true)
            {
                pay = (int)Math.Ceiling(pay_array[start, end] * 0.81 * 2);
            }
            else if (checkBox1.Checked == true) 
            {
                pay = (int)Math.Ceiling(pay_array[start, end] * 0.9 * 2);
            }
            else if (checkBox2.Checked == true)
            {
                pay = (int)Math.Ceiling(pay_array[start, end] * 0.9);
            }
            label3.Text ="票價 : " + pay.ToString();
            check_ns(start, end);           
        }
    }
}
