﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 字串替換
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] num = {"零","一","二","三","四","五","六","七","八","九"};
            Console.Write("輸入: ");
            string input = Console.ReadLine();
            Console.Write("輸出: ");
            for (int i = 0; i < input.Length; i++)
            {
                int val = int.Parse(input[i].ToString());
                Console.Write(num[val]);
            }
            Console.ReadLine();
        }
    }
}
