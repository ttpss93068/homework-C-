﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 滷味
{
    class Calculator
    {
        public int _remainder;

        public Calculator(int total) 
        {
            _remainder = total;
            thousand = GetNumber(1000);
            hundred = GetNumber(100);
            ten = GetNumber(10);
            five = GetNumber(5);
            one = _remainder;
        }
        public int thousand { get;set; }
        public int hundred { get; set; }
        public int ten { get; set; }
        public int five { get; set; }
        public int one { get; set; }

        private int GetNumber(int money) 
        {
            var result = _remainder / money;
            _remainder = _remainder % money;
            return result;
        }
    }
}
