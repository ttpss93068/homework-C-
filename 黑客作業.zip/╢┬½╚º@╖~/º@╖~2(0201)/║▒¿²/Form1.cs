﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 滷味
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        

        private void button1_Click(object sender, EventArgs e)
        {            
            int result1 = 0;
            int result2 = 0;
            int result3 = 0;
            if (checkBox1.Checked == true) 
            {
                int fi_1 = int.Parse(textBox1.Text);
                result1 = 15 * fi_1;               
            }
            if (checkBox2.Checked == true)
            {
                int fi_2 = int.Parse(textBox2.Text);
                result2 = 15 * fi_2;                
            }
            if (checkBox3.Checked == true)
            {
                int fi_3 = int.Parse(textBox3.Text);
                result3 = 30 * fi_3;
            }
            int sum_fi = (result1 + result2 + result3);
            label3.Text = "總共 : " + sum_fi.ToString();
            //int thousand = sum_fi / 1000, hundred = (sum_fi - (thousand * 1000)) / 100,
            //    ten = (sum_fi - (thousand * 1000) - (hundred * 100)) / 10,
            //    fiv = 0,
            //    Singles = (sum_fi - (thousand * 1000) - (hundred * 100) - (ten * 10));
            //if (Singles >= 5) 
            //{
            //    fiv++;
            //    Singles = Singles - 5;
            //}這是沒有用class寫的幾張千元鈔幾張百元鈔...的方式
            Calculator calculator = new Calculator(sum_fi);
            
            label4.Text = $"需付{calculator.thousand}張千元鈔,{calculator.hundred}張百元鈔,{calculator.ten}個十塊,{calculator.five}個五塊,{calculator.one}個一塊";
        }
    }
}
