﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 作業2_0201_
{
    class Program
    {
        static void Main(string[] args)
        {
            int Num = 46;
            for (int i = 1; i <= Num; i++)
            {
                Console.WriteLine(Fib(i) + ",") ; 
            }
            Console.ReadLine();
            //uint v0 = 0; //不用int是因為數字過大會發生overfloat
            //uint v1 = 1;
            //uint temp = 0;
            //while (v1 <= 1836311903)
            //{
            //    Console.WriteLine(v1.ToString());
            //    temp = v1;
            //    v1 += v0;
            //    v0 = temp;
            //}
        }
        private static int Fib(int num)
        {
            if (num <= 2)
                return 1;
            else
                return Fib(num - 1) + Fib(num - 2);
        }
    }
}
