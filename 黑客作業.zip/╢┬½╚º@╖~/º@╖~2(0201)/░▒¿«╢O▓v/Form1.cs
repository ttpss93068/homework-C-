﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 停車費率
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int datatime_day = (int)((dateTimePicker3.Value - dateTimePicker1.Value).TotalMinutes);
            int datatime_time = (int)((dateTimePicker4.Value - dateTimePicker2.Value).TotalMinutes);
            int sum_time = datatime_day + datatime_time;
            Parkingfee parkingfee = new Parkingfee();

            //label7.Text = $"{datatime_day}   {datatime_time}";
            //int pay, t2;
            //if (datatime_day == 0)
            //{
            //    if (datatime_time <= 120)
            //    {
            //        pay = (datatime_time / 30) * 30;
            //    }
            //    else if (datatime_time >= 120 && datatime_time <= 240)
            //    {
            //        t2 = (datatime_time / 30) - 4;
            //        pay = t2 * 40 + 120;
            //    }
            //    else
            //    {
            //        t2 = (datatime_time / 30) - 8;
            //        pay = t2 * 60 + 280;
            //    }
            //} else
            //{
            //    t2 = (datatime_day / 30) - 8;
            //    pay = t2 * 60 + (datatime_time / 30) * 60 + 280;
            //}
            label7.Text = $"需付 : {parkingfee.GetParkingFee(sum_time)}";
        }
    }
}
