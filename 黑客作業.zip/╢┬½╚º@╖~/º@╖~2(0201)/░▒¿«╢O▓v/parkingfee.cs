﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 停車費率
{
    class Parkingfee
    {
        private int _remainder;
        public int GetParkingFee(int minutes) 
        {
            _remainder = minutes / 30;
            return GetPerioodHalfHours(8) * 60 + GetPerioodHalfHours(4) * 40 + _remainder * 30;
        }
        private int GetPerioodHalfHours(int period) 
        {
            var result = _remainder - period;
            if (result < 0) { result = 0; }
            _remainder -= result;
            return result;
        }
    }
}
