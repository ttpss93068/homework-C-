﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IsPrime_simple_
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int i = 0; i <= 100; i++) 
            {
                if (IsPrime(i)) 
                {
                    Console.WriteLine($"{i}是質數");
                }
            }
            Console.ReadLine();
            
        }
        static bool IsPrime(int value) 
        {
            if (value < 0) { throw new AggregateException(); }
            if (value < 2) { return false; }
            if (value == 2) { return true; }
            for (int i = 2; i <= Math.Sqrt(value); i++) 
            {
                if (value % i == 0) 
                {
                    return false;
                }
            }
            return true;
        }
    }
}
