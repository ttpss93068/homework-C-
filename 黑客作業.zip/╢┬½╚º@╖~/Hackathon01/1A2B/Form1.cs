﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1A2B
{
    public partial class Form1 : Form
    {
        List<int> list_ans = null;
        string s_wrong = null;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            List<int> _list = new List<int>();           
            while (_list.Count < 4) 
            {
                int ran = new Random().Next(0, 10);
                if (_list.Contains(ran) == false) { _list.Add(ran); }
            }
            list_ans = _list;
            s_wrong = "BBBBB";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string s = "";
                foreach (var item in list_ans)
                {
                    s += item;
                }
                MessageBox.Show(s);
            }
            catch
            {
                MessageBox.Show("您的遊戲還沒開始");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int a = 0, b = 0;
            try
            {               
                var wro = s_wrong[1] + "A"; // 為了出錯時能執行catch
                string num_str = textBox1.Text;                
                for (int i = 0; i < num_str.Length; i++)
                {
                    string sss = num_str.Substring(i, 1);
                    if ((list_ans[i]).ToString() == sss)
                    {
                        a++;
                    }
                    else if (list_ans.Contains(int.Parse(sss)))
                    {
                        b++;
                    }
                }
                listBox1.Items.Add(num_str + "--" + $"{a}A{b}B");
            }
            catch 
            {
                MessageBox.Show("您的遊戲還沒開始");
            }
            if (a == 4) 
            {
                MessageBox.Show("遊戲通關");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            list_ans = null;
            s_wrong = null;
        }
    }
}
