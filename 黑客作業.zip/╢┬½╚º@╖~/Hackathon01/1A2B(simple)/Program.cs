﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1A2B_simple_
{
    class Program
    {
        static void Main(string[] args)
        {
            var s1 = "1234";
            var s2 = "9235";
            var intersect = s1.Intersect(s2);

            var countOfA = intersect.Count((x) => s1.IndexOf(x) == s2.IndexOf(x));
            var countOfB = intersect.Count() - countOfA;


        }
    }
}
