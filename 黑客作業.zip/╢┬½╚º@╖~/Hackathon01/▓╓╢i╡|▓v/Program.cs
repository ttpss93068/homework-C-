﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 累進稅率
{
    class Program
    {
        static void Main(string[] args)
        {

            while(true)
            {
                //List<int> _list = new List<int>() { 540000, 1210000, 2420000, 4530000, 10310000, 10310000 };
                Console.WriteLine("請輸入你的年收入 :");
                decimal input = decimal.Parse(Console.ReadLine());
                //int num_index = 0;
                decimal rate = 0;
                //for (int i = 0; i < _list.Count; i++)
                //{
                //    if (input > _list[i])
                //    {
                //        num_index = i;
                //    }
                //}

                if (input <= 540000)
                {
                    //num_index = 0;
                    rate = input * 0.05M;
                }
                else if (input > 540000 && input <= 1210000)
                {
                    rate = (input - 540000) * 0.12M + 27000;
                    //num_index = 1;
                }
                else if (input > 1210000 && input <= 2420000)
                {
                    rate = (input - 1210000) * 0.2M + 27000 + 80400;
                    //num_index = 2;
                }
                else if (input > 2420000 && input <= 4530000)
                {
                    rate = (input - 2420000) * 0.3M + 27000 + 80400 + 242000;
                    //num_index = 3;
                }
                else if (input > 4530000 && input <= 10310000)
                {
                    rate = (input - 4530000) * 0.4M + 27000 + 80400 + 242000 + 633000;
                    //num_index = 4;
                }
                else if (input > 10310000)
                {
                    rate = (input - 10310000) * 0.5M + 27000 + 80400 + 242000 + 633000 + 2312000;
                    //num_index = 5;
                }



                //switch (num_index)
                //{
                //    case 0:
                //        rate = input * 0.05M;
                //        break;
                //    case 1:
                //        rate = (input - 540000)*0.12M + 27000 ;
                //        break;
                //    case 2:
                //        rate = (input - 1210000) * 0.2M + 27000 + 80400;
                //        break;
                //    case 3:
                //        rate = (input - 2420000) * 0.3M + 27000 + 80400 + 242000;
                //        break;
                //    case 4:
                //        rate = (input - 4530000) * 0.4M + 27000 + 80400 + 242000 + 633000 ;
                //        break;
                //    case 5:
                //        rate = (input - 10310000) * 0.5M + 27000 + 80400 + 242000 + 633000 + 2312000;
                //        break;
                //}
                Console.WriteLine($"{input} --> {rate}");
                Console.ReadLine();
            }
                      
        }
    }
}
