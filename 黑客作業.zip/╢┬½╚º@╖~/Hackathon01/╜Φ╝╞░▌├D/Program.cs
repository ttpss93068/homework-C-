﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 質數問題
{
    class Program
    {
        static void Main(string[] args)
        {          
            for (int i = 101; i <= 200; i++) 
            {
                int sum = 0;
                for (int j = 1; j <= i; j++) 
                {
                    if (i % j == 0) 
                    {
                        sum++;
                    }
                }
                if (sum == 2)
                {
                    Console.WriteLine($"{i}是質數");
                }
                //else
                //{
                //    Console.WriteLine($"{i}不是質數");
                //}
            }
            Console.ReadLine();
        }
    }
}
