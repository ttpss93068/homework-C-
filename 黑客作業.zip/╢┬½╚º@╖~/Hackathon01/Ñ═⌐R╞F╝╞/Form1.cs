﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace 生命靈數
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var lines = File.ReadAllLines(@"生命靈數.txt");
            int year = dateTimePicker1.Value.Year;
            int month = dateTimePicker1.Value.Month;
            int day = dateTimePicker1.Value.Day;
            string birth = dateTimePicker1.Value.Year.ToString()+ dateTimePicker1.Value.Month.ToString()+ dateTimePicker1.Value.Day.ToString();
            int life_num = 0;
            for (int i = 0; i < birth.Length; i++) 
            {
                life_num += int.Parse(birth.Substring(i, 1));
            }
            while (life_num > 9) 
            {
                var sum = life_num.ToString();
                life_num = 0;
                for (int i = 0; i < sum.Length; i++) 
                {
                    life_num += int.Parse(sum.Substring(i, 1));
                }
            }
            label4.Text = "生命靈數 : " + life_num;
            if (dateTimePicker1.Value.Month == 1 && dateTimePicker1.Value.Day >= 21 || dateTimePicker1.Value.Month == 2 && dateTimePicker1.Value.Day <= 19)
            {
                label3.Text = "你的星座是 : " + "水瓶座";
                var v = lines.ToList().IndexOf(lines.Where((x) => x.Contains("水瓶座")).FirstOrDefault());
                label5.Text = lines[v + life_num * 2] + Environment.NewLine;
            }
            if (dateTimePicker1.Value.Month == 2 && dateTimePicker1.Value.Day >= 20 || dateTimePicker1.Value.Month == 3 && dateTimePicker1.Value.Day <= 20)
            {
                label3.Text = "你的星座是 : " + "雙魚座";
                var v = lines.ToList().IndexOf(lines.Where((x) => x.Contains("雙魚座")).FirstOrDefault());
                label5.Text = lines[v + life_num * 2] + Environment.NewLine;

            }
            if (dateTimePicker1.Value.Month == 3 && dateTimePicker1.Value.Day >= 21 || dateTimePicker1.Value.Month == 4 && dateTimePicker1.Value.Day <= 19)
            {
                label3.Text = "你的星座是 : " + "牡羊座";
                var v = lines.ToList().IndexOf(lines.Where((x) => x.Contains("牡羊座")).FirstOrDefault());
                label5.Text = lines[v + life_num * 2] + Environment.NewLine;

            }
            if (dateTimePicker1.Value.Month == 4 && dateTimePicker1.Value.Day >= 20 || dateTimePicker1.Value.Month == 5 && dateTimePicker1.Value.Day <= 20)
            {
                label3.Text = "你的星座是 : " + "金牛座";
                var v = lines.ToList().IndexOf(lines.Where((x) => x.Contains("金牛座")).FirstOrDefault());
                label5.Text = lines[v + life_num * 2] + Environment.NewLine;

            }
            if (dateTimePicker1.Value.Month == 5 && dateTimePicker1.Value.Day >= 21 || dateTimePicker1.Value.Month == 6 && dateTimePicker1.Value.Day <= 21)
            {
                label3.Text = "你的星座是 : " + "雙子座";
                var v = lines.ToList().IndexOf(lines.Where((x) => x.Contains("雙子座")).FirstOrDefault());
                label5.Text = lines[v + life_num * 2] + Environment.NewLine;

            }
            if (dateTimePicker1.Value.Month == 6 && dateTimePicker1.Value.Day >= 22 || dateTimePicker1.Value.Month == 7 && dateTimePicker1.Value.Day <= 22)
            {
                label3.Text = "你的星座是 : " + "巨蟹座";
                var v = lines.ToList().IndexOf(lines.Where((x) => x.Contains("巨蟹座")).FirstOrDefault());
                label5.Text = lines[v + life_num * 2] + Environment.NewLine;

            }
            if (dateTimePicker1.Value.Month == 7 && dateTimePicker1.Value.Day >= 23 || dateTimePicker1.Value.Month == 8 && dateTimePicker1.Value.Day <= 22)
            {
                label3.Text = "你的星座是 : " + "獅子座";
                var v = lines.ToList().IndexOf(lines.Where((x) => x.Contains("獅子座")).FirstOrDefault());
                label5.Text = lines[v + life_num * 2] + Environment.NewLine;

            }
            if (dateTimePicker1.Value.Month == 8 && dateTimePicker1.Value.Day >= 23 || dateTimePicker1.Value.Month == 9 && dateTimePicker1.Value.Day <= 22)
            {
                label3.Text = "你的星座是 : " + "處女座";
                var v = lines.ToList().IndexOf(lines.Where((x) => x.Contains("處女座")).FirstOrDefault());
                label5.Text = lines[v + life_num * 2] + Environment.NewLine;

            }
            if (dateTimePicker1.Value.Month == 9 && dateTimePicker1.Value.Day >= 23 || dateTimePicker1.Value.Month == 10 && dateTimePicker1.Value.Day <= 23)
            {
                label3.Text = "你的星座是 : " + "天秤座";
                var v = lines.ToList().IndexOf(lines.Where((x) => x.Contains("天秤座")).FirstOrDefault());
                label5.Text = lines[v + life_num * 2] + Environment.NewLine;

            }
            if (dateTimePicker1.Value.Month == 10 && dateTimePicker1.Value.Day >= 24 || dateTimePicker1.Value.Month == 11 && dateTimePicker1.Value.Day <= 21)
            {
                label3.Text = "你的星座是 : " + "天蠍座";
                var v = lines.ToList().IndexOf(lines.Where((x) => x.Contains("天蠍座")).FirstOrDefault());
                label5.Text = lines[v + life_num * 2] + Environment.NewLine;

            }
            if (dateTimePicker1.Value.Month == 11 && dateTimePicker1.Value.Day >= 22 || dateTimePicker1.Value.Month == 12 && dateTimePicker1.Value.Day <= 20)
            {
                label3.Text = "你的星座是 : " + "射手座";
                var v = lines.ToList().IndexOf(lines.Where((x) => x.Contains("射手座")).FirstOrDefault());
                label5.Text = lines[v + life_num * 2] + Environment.NewLine;

            }
            if (dateTimePicker1.Value.Month == 12 && dateTimePicker1.Value.Day >= 21 || dateTimePicker1.Value.Month == 1 && dateTimePicker1.Value.Day <= 20)
            {
                label3.Text = "你的星座是 : " + "魔羯座";
                var v = lines.ToList().IndexOf(lines.Where((x) => x.Contains("魔羯座")).FirstOrDefault());
                label5.Text = lines[v + life_num * 2] + Environment.NewLine;

            }
        }
    }
}
