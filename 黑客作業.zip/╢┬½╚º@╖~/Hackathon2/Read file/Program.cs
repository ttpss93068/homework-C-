﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Read_file.Models;

namespace Read_file
{
    class Program
    {
        static void Main(string[] args)
        {
            //DateTime T;
            var file = File.ReadAllLines("test03.TXT");
            var result = file.Where(x => (x.Substring(0, 3) == "695" || x.Substring(0, 3) == "525"));
            //&& (DateTime.TryParse($"{x.Substring(13,4)} - {x.Substring(17,2)} - {x.Substring(19,2)}") || x == "999999999")
            //&& (DateTime.TryParse(convert(x.Substring(21, 8)), out T)));
            //List<string> list_695 = new List<string>();
            //for (int i = 0; i < file.Length; i++) 
            //{
            //    if (file[i].Substring(0, 3) == "695" || file[i].Substring(0, 3) == "525") 
            //    {
            //        list_695.Add(file[i]);
            //    }
            //}
            string num;
            DateTime fly;
            DateTime birth;
            foreach (var item in result) 
            {
                num = item.Substring(0, 12);
                if (item.Substring(13, 8) == "99999999")
                {
                    fly = DateTime.MaxValue;
                }
                else 
                {
                    fly = DateTime.Parse($"{item.Substring(13, 4)} - {item.Substring(17, 2)} - {item.Substring(19, 2)}");
                }
                birth = DateTime.Parse($"{item.Substring(21, 4)} - {item.Substring(25, 2)} - {item.Substring(27, 2)}");

                Table datas = new Table();
                datas = new Table
                {
                    TickNumber = num,
                    FlyingDay = fly,
                    Birthday = birth
                };
                DataModel model = new DataModel();
                model.Table.Add(datas);
                model.SaveChanges();
                Console.WriteLine("你可以出師了");
            }

            Console.ReadLine();
        }
        //static string convert(string s) 
        //{
        //    return $"{s.Substring(0, 4)}/{s.Substring(4, 2)}/{s.Substring(6, 2)}";
        //}
    }
}
