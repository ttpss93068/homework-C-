﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace count_string
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> _list = new List<string>();
            var input = Console.ReadLine().ToLower().Split(' ');
            foreach (var item in input) 
            {
                _list.Add(item);                         
            }
            var distinct = _list.Distinct().ToList();
            for (int i = 0; i < distinct.Count(); i++) 
            {
                var count = _list.FindAll(x => x == distinct[i].ToString()).Count();
                Console.WriteLine($"{distinct[i]} : {count}");
            }

            Console.ReadLine();           
        }
    }
}
