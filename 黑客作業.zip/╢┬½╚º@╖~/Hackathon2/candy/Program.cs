﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace candy
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("你要定義幾個包裝紙買幾顆 ? ");
            int paper = int.Parse(Console.ReadLine());
            Console.WriteLine("你想要吃幾顆 ? ");
            int want = int.Parse(Console.ReadLine());
            //int x = 0, y = 0, result = 0, total = 0;//result = 是依照糖果紙數能換多少顆糖
            //while (total != want) 
            //{
            //    result = (want - y) / paper;
            //    x = (want - y);// x 是想要糖果數減去能換幾顆糖
            //    y = result;  // y 是能換幾顆糖
            //    total = y + x; // total 相加起來為想要糖果數
            //}
            int buy = 0, wrap = 0, have = 0;
            while (want > have) 
            {
                buy++;
                have++;
                wrap++;

                if (wrap == paper) 
                {
                    have++;
                    wrap = 1;
                }
            }

            Console.WriteLine($"你最少需要買 {buy} 顆糖果");
            Console.ReadLine();
        }
    }
}
