﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace buy_chicken
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = 0;//公雞
            int y = 0;//母雞
            int z = 0;//小雞
            while ((x + y + z != 100) && (60 * x + 30 * y + z != 1000))
            {
                x++;
                if ((900 - 59 * x) % 29 == 0) 
                {
                    y = (900 - 59 * x) / 29;
                    z = 100 - x - y;
                }
            }
            Console.WriteLine($"公雞要買 {x} 隻,母雞要買 {y} 隻,小雞要買 {z} 隻");
            Console.ReadLine();
        }
    }
}
