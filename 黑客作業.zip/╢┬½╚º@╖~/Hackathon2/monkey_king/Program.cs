﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace monkey_king
{
    class Program
    {
        static void Main(string[] args)
        {
            //List<int> original = new List<int>();
            //List<int> remove = new List<int>();
            //int start = 100;
            //var result2 = new List<int>();
            //for (int i = 1; i <= start; i++) 
            //{
            //    original.Add(i);
            //}
            //for (int i = 2; i <= start; i += 3) 
            //{
            //    remove.Add(original[i]);
            //}
            //var result = original.Except(remove).ToList();
            ////while (original.Count() > 1)
            ////{
            //    original.Clear();
            //    int num = original.Count() - remove.Count() - 1;
            //    original.Add(result[num]);
            //    for (int i = 0; i < result.Count() - 1; i++) 
            //    {
            //        original.Add(result[i]);
            //    }
            ////}
            ///
            Console.WriteLine(GetKing(1000,3));
            Console.ReadLine();

        }
        public static int GetKing(int monkeyNum, int loopLength)
        {
            List<int> monkeys = new List<int>();
            for (int i = 1; i <= monkeyNum; i++) monkeys.Add(i);

            int position = 0;
            while (true)
            {
                for (int i = 1; i <= loopLength; i++)
                {
                    if (i == loopLength)
                    {
                        monkeys.Remove(monkeys[position]);
                        position = position == 0 ? position = monkeys.Count - 1 : position - 1;
                    }
                    position = position == monkeys.Count - 1 ? 0 : position + 1;
                }

                if (monkeys.Count == 1) return monkeys[0];
            }
        }
    }
}
