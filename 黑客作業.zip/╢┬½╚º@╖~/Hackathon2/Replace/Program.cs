﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Replace
{
    class Program
    {
        static void Main(string[] args)
        {
            var input = Console.ReadLine();
            List<int> list  = new List<int> (){ int.Parse(input) };
            var over90 = list.Where((x) => x > 90).ToList();
            var num = over90[0];
            for (int i = 1; i <= num; i++) 
            {
                string s = i.ToString();
                if (i % 3 == 0 && i % 5 == 0)
                {
                    s = "Dann";
                }
                else if (i % 3 == 0) 
                {
                    s = "Build";
                }
                else if (i % 5 == 0)
                {
                    s = "School";
                }
                Console.WriteLine(s);
            }
            Console.ReadLine();
        }
    }
}
