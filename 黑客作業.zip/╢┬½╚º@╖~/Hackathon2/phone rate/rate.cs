﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace phone_rate
{
    class rate
    {
        public string name { set; get; }
        public int total { set; get; }
    }
}
