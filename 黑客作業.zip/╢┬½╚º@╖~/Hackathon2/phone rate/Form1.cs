﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace phone_rate
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();                      
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var num = int.Parse(textBox1.Text);          
            List<rate> rates = new List<rate>()
            {
                new rate() { name = "中華電信", total = num * 4 + 350 },
                new rate() { name = "遠傳", total = num * 3 + 400 },
                new rate() { name = "台灣大哥大", total = num * 2 + 500 }
            };
            var cheap = rates.FindAll(x => x.total == rates.Min(y => y.total)).ToList();
            var pay = rates.FindAll(x => x.total == rates.Min(y => y.total)).First();
            string s = string.Empty;
            
            foreach (var item in cheap) 
            {
                s += $"{item.name} ,"; 
            }
            label4.Text = s.Trim(',');
            label5.Text = pay.total.ToString();
        }
    }
}
