﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_LED
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("請輸入一串數字 : ");
            string input = Console.ReadLine();
            int count = 0;
            foreach (var item in input) 
            {
                if (item == '1') 
                {
                    one(count);
                    count += 4;
                }
                if (item == '2')
                {
                    two(count);
                    count += 4;
                }
                if (item == '3')
                {
                    three(count);
                    count += 4;
                }
                if (item == '4')
                {
                    four(count);
                    count += 4;
                }
                if (item == '5')
                {
                    five(count);
                    count += 4;
                }
                if (item == '6')
                {
                    six(count);
                    count += 4;
                }
                if (item == '7')
                {
                    seven(count);
                    count += 4;
                }
                if (item == '8')
                {
                    eight(count);
                    count += 4;
                }
                if (item == '9')
                {
                    nine(count);
                    count += 4;
                }

            }
            Console.ReadLine();
        }
        static void one(int x) 
        { 
            Console.SetCursorPosition(x, 3);
            Console.WriteLine(" |");
            Console.SetCursorPosition(x, 4);
            Console.WriteLine(" |");
        }

        static void two(int x)
        {
            Console.SetCursorPosition(x, 2);
            Console.WriteLine("  _ ");
            Console.SetCursorPosition(x, 3);
            Console.WriteLine("  _|");
            Console.SetCursorPosition(x, 4);
            Console.WriteLine(" |_ ");
        }
        static void three(int x)
        {
            Console.SetCursorPosition(x, 2);
            Console.WriteLine("  _ ");
            Console.SetCursorPosition(x, 3);
            Console.WriteLine("  _|");
            Console.SetCursorPosition(x, 4);
            Console.WriteLine("  _|");
        }
        static void four(int x)
        {
            Console.SetCursorPosition(x, 3);
            Console.WriteLine(" |_|");
            Console.SetCursorPosition(x, 4);
            Console.WriteLine("   |");
        }
        static void five(int x)
        {
            Console.SetCursorPosition(x, 2);
            Console.WriteLine("  _ ");
            Console.SetCursorPosition(x, 3);
            Console.WriteLine(" |_ ");
            Console.SetCursorPosition(x, 4);
            Console.WriteLine("  _|");
        }
        static void six(int x)
        {
            Console.SetCursorPosition(x, 2);
            Console.WriteLine("  _ ");
            Console.SetCursorPosition(x, 3);
            Console.WriteLine(" |_ ");
            Console.SetCursorPosition(x, 4);
            Console.WriteLine(" |_|");
        }
        static void seven(int x)
        {
            Console.SetCursorPosition(x, 2);
            Console.WriteLine("  _ ");
            Console.SetCursorPosition(x, 3);
            Console.WriteLine(" | |");
            Console.SetCursorPosition(x, 4);
            Console.WriteLine("   |");
        }
        static void eight(int x)
        {
            Console.SetCursorPosition(x, 2);
            Console.WriteLine("  _ ");
            Console.SetCursorPosition(x, 3);
            Console.WriteLine(" |_|");
            Console.SetCursorPosition(x, 4);
            Console.WriteLine(" |_|");
        }
        static void nine(int x)
        {
            Console.SetCursorPosition(x, 2);
            Console.WriteLine("  _ ");
            Console.SetCursorPosition(x, 3);
            Console.WriteLine(" |_|");
            Console.SetCursorPosition(x, 4);
            Console.WriteLine("  _|");
        }

    }
}
