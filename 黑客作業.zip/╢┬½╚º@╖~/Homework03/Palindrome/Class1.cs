﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Palindrome
{
    class Class1
    {       
        public string judge (string s)
        {
            string s_t = "不是回文";
            for (int i = 0; i < s.Length; i++) 
            {
                if (s[i] == s[s.Length - 1 - i]) 
                {
                    s_t = "是回文";
                }
            }
            return s_t;
        }
    }
}
