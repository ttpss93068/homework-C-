﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Palindrome
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("請輸入一串字串 :");
            string input = Console.ReadLine();
            Class1 Palindrome = new Class1();
            Console.WriteLine(input + Palindrome.judge(input));          
            Console.ReadLine();
        }
    }
}
