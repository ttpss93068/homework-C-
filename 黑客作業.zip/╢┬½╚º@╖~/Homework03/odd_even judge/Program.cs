﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace odd_even_judge
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("輸入");
            var input = Console.ReadLine();
            //var number = new List<int>();
            //foreach (var item in input) 
            //{
            //    number.Add(int.Parse(item));
            //}
            var result = input.Split(',')
                .Select((x) => int.Parse(x))
                .OrderBy((x) => x)
                .GroupBy((x) => x % 2)
                .OrderByDescending((x) => x.Key)
                .Select((x) => $"{(x.Key == 1 ? "奇數" : "偶數")} : {string.Join(",", x)}");

            foreach (var items in result) 
            {
                Console.WriteLine(items);
            }

            //var odd = number.Where((x) => x % 2 != 0).ToList();
            //var even = number.Where((x) => x % 2 == 0).ToList();
            //Dispaly("奇數", odd);
            //Dispaly("偶數", even);
            Console.ReadLine();
        }

        static void Dispaly(string s, List<int> num)
        {
            Console.Write($"{s} : ");
            for(int i = 0; i < num.Count; i++)
            {
                if (i == 0) 
                {
                    Console.Write(num[i]); 
                }
                else 
                {
                    Console.Write("," + num[i]); 
                }
            }
            Console.WriteLine("");
        }
    }
}
