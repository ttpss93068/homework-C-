﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Performance_calculation
{
    class Class1
    {
        public string name { get; set; }
        public int ballpoint { get; set; }
        public int pen { get; set; }
        public int eraser { get; set; }
        public int ruler { get; set; }
        public int Lico { get; set; }
        public int sales_sum { get; set; }

    }
    class Class2
    {
        public int ballpoint_2 { get; set; }
        public int pen_2 { get; set; }
        public int eraser_2 { get; set; }
        public int ruler_2 { get; set; }
        public int Lico_2 { get; set; }

    }
}
