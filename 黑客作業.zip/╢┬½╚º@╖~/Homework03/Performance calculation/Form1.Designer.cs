﻿namespace Performance_calculation
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ballpoint = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pen = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.eraser = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ruler = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Lico = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sales_sum = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.總銷售金額 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ballpoint_2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pen_2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.eraser_2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ruler_2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Lico_2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.name,
            this.ballpoint,
            this.pen,
            this.eraser,
            this.ruler,
            this.Lico,
            this.sales_sum});
            this.dataGridView1.Location = new System.Drawing.Point(12, 31);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(758, 151);
            this.dataGridView1.TabIndex = 0;
            // 
            // name
            // 
            this.name.DataPropertyName = "name";
            this.name.HeaderText = "業務員";
            this.name.Name = "name";
            this.name.ReadOnly = true;
            // 
            // ballpoint
            // 
            this.ballpoint.DataPropertyName = "ballpoint";
            this.ballpoint.HeaderText = "原子筆";
            this.ballpoint.Name = "ballpoint";
            this.ballpoint.ReadOnly = true;
            // 
            // pen
            // 
            this.pen.DataPropertyName = "pen";
            this.pen.HeaderText = "鉛筆";
            this.pen.Name = "pen";
            this.pen.ReadOnly = true;
            // 
            // eraser
            // 
            this.eraser.DataPropertyName = "eraser";
            this.eraser.HeaderText = "橡皮擦";
            this.eraser.Name = "eraser";
            this.eraser.ReadOnly = true;
            // 
            // ruler
            // 
            this.ruler.DataPropertyName = "ruler";
            this.ruler.HeaderText = "直尺";
            this.ruler.Name = "ruler";
            this.ruler.ReadOnly = true;
            // 
            // Lico
            // 
            this.Lico.DataPropertyName = "Lico";
            this.Lico.HeaderText = "立可白";
            this.Lico.Name = "Lico";
            this.Lico.ReadOnly = true;
            // 
            // sales_sum
            // 
            this.sales_sum.DataPropertyName = "sales_sum";
            this.sales_sum.HeaderText = "銷售總金額";
            this.sales_sum.Name = "sales_sum";
            this.sales_sum.ReadOnly = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(61, 401);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 12);
            this.label1.TabIndex = 1;
            this.label1.Text = "label1";
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.總銷售金額,
            this.ballpoint_2,
            this.pen_2,
            this.eraser_2,
            this.ruler_2,
            this.Lico_2});
            this.dataGridView2.Location = new System.Drawing.Point(12, 231);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(669, 85);
            this.dataGridView2.TabIndex = 2;
            // 
            // 總銷售金額
            // 
            this.總銷售金額.DataPropertyName = "總銷售金額";
            this.總銷售金額.HeaderText = "總銷售金額";
            this.總銷售金額.Name = "總銷售金額";
            this.總銷售金額.ReadOnly = true;
            // 
            // ballpoint_2
            // 
            this.ballpoint_2.DataPropertyName = "ballpoint_2";
            this.ballpoint_2.HeaderText = "原子筆";
            this.ballpoint_2.Name = "ballpoint_2";
            this.ballpoint_2.ReadOnly = true;
            // 
            // pen_2
            // 
            this.pen_2.DataPropertyName = "pen_2";
            this.pen_2.HeaderText = "鉛筆";
            this.pen_2.Name = "pen_2";
            this.pen_2.ReadOnly = true;
            // 
            // eraser_2
            // 
            this.eraser_2.DataPropertyName = "eraser_2";
            this.eraser_2.HeaderText = "橡皮擦";
            this.eraser_2.Name = "eraser_2";
            this.eraser_2.ReadOnly = true;
            // 
            // ruler_2
            // 
            this.ruler_2.DataPropertyName = "ruler_2";
            this.ruler_2.HeaderText = "直尺";
            this.ruler_2.Name = "ruler_2";
            this.ruler_2.ReadOnly = true;
            // 
            // Lico_2
            // 
            this.Lico_2.DataPropertyName = "Lico_2";
            this.Lico_2.HeaderText = "立可白";
            this.Lico_2.Name = "Lico_2";
            this.Lico_2.ReadOnly = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn name;
        private System.Windows.Forms.DataGridViewTextBoxColumn ballpoint;
        private System.Windows.Forms.DataGridViewTextBoxColumn pen;
        private System.Windows.Forms.DataGridViewTextBoxColumn eraser;
        private System.Windows.Forms.DataGridViewTextBoxColumn ruler;
        private System.Windows.Forms.DataGridViewTextBoxColumn Lico;
        private System.Windows.Forms.DataGridViewTextBoxColumn sales_sum;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridViewTextBoxColumn 總銷售金額;
        private System.Windows.Forms.DataGridViewTextBoxColumn ballpoint_2;
        private System.Windows.Forms.DataGridViewTextBoxColumn pen_2;
        private System.Windows.Forms.DataGridViewTextBoxColumn eraser_2;
        private System.Windows.Forms.DataGridViewTextBoxColumn ruler_2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Lico_2;
    }
}

