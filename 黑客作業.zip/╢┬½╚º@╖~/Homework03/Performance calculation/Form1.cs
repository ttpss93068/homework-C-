﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Performance_calculation
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            var _list = Sales_amount();
            int bal = 0, pe = 0, era = 0, rul = 0, lic = 0; 
            for (int i = 0; i < _list.Count(); i++) 
            {
                bal += _list[i].ballpoint;
                pe += _list[i].pen;
                era += _list[i].eraser;
                rul += _list[i].ruler;
                lic += _list[i].Lico;
            }
            var total_sum = new Class1()
            {
                ballpoint = bal * 12,
                pen = pe * 16,
                eraser = era * 10,
                ruler = rul * 14,
                Lico = lic * 15
            };
            _list.Add(total_sum);
            dataGridView1.DataSource = _list;
            int max = 0;
            for (int i = 0; i < _list.Count(); i++) 
            {
                if (_list[i].sales_sum > max) 
                {
                    max = _list[i].sales_sum;
                    label1.Text = _list[i].name;
                }
            }

        }
        private List<Class1> Sales_amount()
        {
            var price = new Class1
            {
                ballpoint = 12,
                pen = 16,
                eraser = 10,
                ruler = 14,
                Lico = 15,
            };
            var result = new List<Class1>();
            string[] lines = File.ReadAllLines("業績計算.csv");
            for (int i = 1; i < lines.Count(); i++) 
            {
                string[] items = lines[i].Split(',');
                var sales = new Class1
                {
                    name = items[0],
                    ballpoint = int.Parse(items[1]),
                    pen = int.Parse(items[2]),
                    eraser = int.Parse(items[3]),
                    ruler = int.Parse(items[4]),
                    Lico = int.Parse(items[5]),
                };
                int sum = sales.ballpoint * price.ballpoint + sales.pen * price.pen + sales.eraser * price.eraser
                    + sales.ruler * price.ruler + sales.Lico * price.Lico;
                sales.sales_sum = sum;
                result.Add(sales);
            }
            return result;
        }

    }
}

