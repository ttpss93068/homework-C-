﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace simple_math_calculation
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("輸入奇數或偶數 : ");
            int input = int.Parse(Console.ReadLine());
            if (input >= 1) 
            {
                if (input % 2 == 0)
                {
                    var even = input / 2 * (-1);
                    Console.WriteLine(even);
                }
                else 
                {
                    var odd = input / 2 + 1;
                    Console.WriteLine(odd);
                }
            }
            Console.ReadLine();
        }
    }
}
